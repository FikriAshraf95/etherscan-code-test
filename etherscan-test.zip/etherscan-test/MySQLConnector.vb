﻿Imports Microsoft.VisualBasic

Imports MySql.Data.MySqlClient

Public Class MySQLConnector
    Private _connectionString As String
    Private _connection As MySqlConnection

    Public Sub New(connectionString As String)
        _connectionString = connectionString
    End Sub

    Public Shared ReadOnly Property Connection As MySqlConnection
        Get
            If _connection Is Nothing Then
                _connection = New MySqlConnection(_connectionString)
            End If

            If _connection.State <> ConnectionState.Open Then
                _connection.Open()
            End If

            Return _connection
        End Get
    End Property

    Public Sub CloseConnection()
        If _connection IsNot Nothing AndAlso _connection.State <> ConnectionState.Closed Then
            _connection.Close()
        End If
    End Sub
End Class
