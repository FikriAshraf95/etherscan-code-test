﻿Public Class Result
    Public Property difficulty As String
End Class
