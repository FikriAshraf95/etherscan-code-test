﻿Public Class eth_getTransactionByBlockNumberAndIndex
    Public Property jsonrpc As String
    Public Property id As String
    Public Property result As eth_getTransactionByBlockNumberAndIndexResult
End Class
