﻿Imports System.Data
Imports Microsoft.SqlServer
Imports MySql.Data.MySqlClient

Public Class MySQLConnectionManager
    Public connectionString As String
    Public connection As MySqlConnection

    'localhost'
    '-- START --
    Dim SERVER_VALUE As String = "localhost"
    Dim DATABASE_VALUE As String = "etherscan"
    Dim USERNAME_VALUE As String = "root"
    Dim PASSWORD_VALUE As String = "root"
    '-- END --

    'Dim SERVER_VALUE As String = "159.223.74.140"
    'Dim DATABASE_VALUE As String = "etherscan"
    'Dim USERNAME_VALUE As String = "etherscan_all"
    'Dim PASSWORD_VALUE As String = "etherscan"

    Public Sub New()
        connectionString = "server=" & SERVER_VALUE & ";user id=" & USERNAME_VALUE & ";password=" & PASSWORD_VALUE & ";database=" & DATABASE_VALUE & ""
        connection = New MySqlConnection()
    End Sub

    Public Sub Open()
        connection.ConnectionString = connectionString
        connection.Open()
    End Sub

    Public Sub Close()
        connection.Close()
    End Sub
End Class
