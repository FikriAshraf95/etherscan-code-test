﻿Public Class eth_getBlockByNumberResultTransactions
    'Public Property transactions As String
End Class
