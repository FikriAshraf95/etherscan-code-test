﻿Public Class eth_getTransactionByBlockNumberAndIndexResult
    Public Property hash As String
    Public Property [from] As String
    Public Property [to] As String
    Public Property value As String
    Public Property gas As String
    Public Property gasPrice As String
    Public Property transactionIndex As String
End Class
