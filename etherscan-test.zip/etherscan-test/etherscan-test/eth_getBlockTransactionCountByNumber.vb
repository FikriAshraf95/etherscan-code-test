﻿Public Class eth_getBlockTransactionCountByNumber
    Public Property jsonrpc As String
    Public Property id As String
    Public Property result As String
End Class
