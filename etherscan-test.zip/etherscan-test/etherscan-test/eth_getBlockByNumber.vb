﻿Public Class eth_getBlockByNumber
    Public Property jsonrpc As String
    Public Property id As String
    Public Property result As eth_getBlockByNumberResult
End Class
