﻿Public Class ResponseData2
    Public Property jsonrpc As String
    Public Property id As String
    Public Property result As String
End Class
