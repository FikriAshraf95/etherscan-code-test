﻿Public Class ResponseData
    'Public Property responseData As String
    Public Property jsonrpc As String
    Public Property id As String
    Public Property result As Result
End Class
