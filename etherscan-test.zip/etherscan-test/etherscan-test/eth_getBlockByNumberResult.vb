﻿Imports Newtonsoft.Json
Imports Newtonsoft.Json.Linq
Public Class eth_getBlockByNumberResult
    Public Property blockNumber As String
    Public Property hash As String
    Public Property parentHash As String
    Public Property miner As String
    Public Property gasLimit As String
    Public Property gasUsed As String
    Public Property transactions As JArray
End Class
