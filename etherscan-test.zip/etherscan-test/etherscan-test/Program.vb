Imports System
Imports System.Data
Imports MySql.Data.MySqlClient
Imports System.IO
Imports System.Text
Imports System.Net.Http
Imports Mysqlx.XDevAPI.Common
Imports etherscan_test.MySQLConnectionManager
Imports Org.BouncyCastle.Asn1.Ocsp
Imports Newtonsoft.Json
Imports System.Diagnostics
Imports Newtonsoft.Json.Linq
Imports System.Text.Json.Nodes
Imports Google.Protobuf.WellKnownTypes
Imports System.Numerics
Imports Org.BouncyCastle.Utilities
Imports System.Globalization

Module Program
    Dim API_KEY As String = "Q1UFWID9VHQYAADPB16VQ3C2PTZI8GGFX4"

    Sub Main()
        Dim BLOCKSTARTNO As Integer = Nothing
        Dim BLOCKLASTNO As Integer = Nothing
        Dim count As Integer = 1
        Dim stopwatch As New Stopwatch()
        Dim elapsed As TimeSpan = Nothing
        Dim blockNoHex As String = Nothing

        stopwatch.Start()
        elapsed = stopwatch.Elapsed

        'Test
        '-- Start --
        'Dim vBol As Boolean = Nothing
        'blockNoHex = ConvertDecToHex(12100006)
        'Console.WriteLine(count & ": " & 12100006 & " --> " & blockNoHex)
        'vBol = GetblockNo(blockNoHex)
        '-- End --

        Console.WriteLine("Program Started")
        Console.WriteLine(vbCrLf) 'Spacing

        Console.WriteLine("Options:")
        Console.WriteLine("1. Block #12100001 - #12100500(default)")
        Console.WriteLine("2. Block #12100001 - #12100005")
        Console.Write(vbCrLf)
        Console.WriteLine("Enter your input:")
        Dim input As String = Console.ReadLine()
        Console.Write(vbCrLf)

        If input.Equals("1") Or input.Equals(Nothing) Or input.Equals("") Then
            Console.WriteLine("Processing Block #12100001 - #12100500")
            BLOCKSTARTNO = 12100001
            BLOCKLASTNO = 12100500
        ElseIf input.Equals("2") Then
            Console.WriteLine("Processing. Block #12100001 - #12100005")
            BLOCKSTARTNO = 12100001
            BLOCKLASTNO = 12100005
        Else
            Console.WriteLine("Input Not Valid")
            Console.WriteLine("Program Ended")
            Exit Sub
        End If

        Console.Write(vbCrLf)
        Console.WriteLine("Program Running ..")
        Console.Write(vbCrLf)

        For i = BLOCKSTARTNO To BLOCKLASTNO
            Dim currentBlockNo As String = i.ToString
            Dim vBol As Boolean = Nothing
            blockNoHex = ConvertDecToHex(i)
            Console.WriteLine(count & ": " & i & " --> " & blockNoHex)

            'call eth_getBlockByNumber API
            vBol = GetblockNo(blockNoHex)

            count += 1
        Next

        stopwatch.Stop()

        Console.WriteLine("Program Ended")
        Console.Write(vbCrLf)
        Console.WriteLine($"Program Running Time - {stopwatch.Elapsed.Hours} hours, {stopwatch.Elapsed.Minutes} minutes, {stopwatch.Elapsed.Seconds} seconds")
        Console.WriteLine(DateTime.Now.ToString)
        Console.WriteLine(vbCrLf)
        Console.WriteLine("Log File Can Be Found in:")
        Console.WriteLine("etherscan-test/etherscan-test/bin/Debug/net6.0/logs")

    End Sub

#Region "Main Functions"
    Public Function GetblockNo(ByVal blockNoHex As String)
        Dim apiUrl As String = "https://api.etherscan.io/api?module=proxy&action=eth_getBlockByNumber&tag=" & blockNoHex & "&boolean=true&apikey=" & API_KEY
        Dim httpClient As New HttpClient()
        Dim response As HttpResponseMessage = Nothing
        Dim content As HttpContent = Nothing
        Dim result As String = Nothing
        Dim vBol As Boolean = Nothing

        response = httpClient.GetAsync(apiUrl).Result
        content = response.Content

        Dim json As String = response.Content.ReadAsStringAsync().Result
        Dim responseData As eth_getBlockByNumber = JsonConvert.DeserializeObject(Of eth_getBlockByNumber)(json)
        If IsNothing(responseData.result) Then
            vBol = False
        Else
            Dim blockTransactionNo As String = GetBlockTransactionNumber(blockNoHex).ToString
            Dim blockNo As String = ConvertHexToInt(blockNoHex)
            Dim hash As String = responseData.result.hash.ToString
            Dim parentHash As String = responseData.result.parentHash.ToString
            Dim miner As String = responseData.result.miner.ToString
            Dim gasLimit As String = ConvertHexToInt(responseData.result.gasLimit.ToString)
            Dim gasUsed As String = ConvertHexToInt(responseData.result.gasUsed.ToString)
            Dim transactionsJson As String = responseData.result.transactions.ToString
            Dim transactionsJsonArray As JArray = JArray.Parse(transactionsJson)

            Dim startTimeBlock As DateTime = DateTime.Now
            Console.WriteLine($"Inserting Block Information For: {ConvertHexToInt(blockNoHex)}({blockNoHex})")
            Dim insertedID As String = InsertBlockRecord(blockNo, hash, parentHash, miner, gasLimit, gasUsed)

            Console.WriteLine("Transaction Count: " & blockTransactionNo)

            If Integer.Parse(blockTransactionNo) <> 0 Then

                For Each item As JObject In transactionsJsonArray
                    Dim startTime As DateTime = DateTime.Now

                    Dim transactionIndex As String = item("transactionIndex").ToString()
                    vBol = GetTransactionByBlock(insertedID, blockNo, blockNoHex, transactionIndex)
                    Dim diff As TimeSpan = DateTime.Now - startTime
                    Dim processedTime As String = diff.ToString("hh\:mm\:ss\:fff")
                    Console.WriteLine($"Transaction Index: {transactionIndex}({ConvertHexToInt(transactionIndex)}) -- Timestamp: {Format(DateTime.Now, "hh:mm:ss tt")}, Processing Time: {processedTime}")
                    LogDataTransaction(blockNo, transactionIndex, processedTime)
                Next
                Console.WriteLine(vbCrLf)
                Console.WriteLine("-------------------------------------------------------------------------")
                Console.WriteLine(vbCrLf)
            End If
            Dim diffBlock As TimeSpan = DateTime.Now - startTimeBlock
            Dim processedTimeBlock As String = diffBlock.ToString("hh\:mm\:ss\:fff")
            Console.WriteLine($"Block No: {blockNo}({blockNoHex}) -- Timestamp: {Format(DateTime.Now, "hh:mm:ss tt")}, Processing Time: {processedTimeBlock}")
            Console.WriteLine(vbCrLf)
            Console.WriteLine("-------------------------------------------------------------------------")
            Console.WriteLine(vbCrLf)
            LogDataBlock(blockNo, processedTimeBlock)
        End If

        Return vBol
    End Function

    Public Function GetBlockTransactionNumber(ByVal blockNoHex As String)
        Dim apiUrl As String = "https://api.etherscan.io/api?module=proxy&action=eth_getBlockTransactionCountByNumber&tag=" & blockNoHex & "&boolean=true&apikey=" & API_KEY
        Dim httpClient As New HttpClient()
        Dim response As HttpResponseMessage = Nothing
        Dim content As HttpContent = Nothing

        response = httpClient.GetAsync(apiUrl).Result
        content = response.Content

        Dim json As String = response.Content.ReadAsStringAsync().Result
        Dim responseData As eth_getBlockTransactionCountByNumber = JsonConvert.DeserializeObject(Of eth_getBlockTransactionCountByNumber)(json)
        Dim countTransactionHex As String = responseData.result.ToString
        Dim countTransactionDec As String = ConvertHexToInt(countTransactionHex)

        Return countTransactionDec
    End Function

    Public Function GetTransactionByBlock(ByVal insertedID As String, ByVal blockNo As String, ByVal blockNoHex As String, ByVal transactionIndex As String)
        Dim apiUrl As String = "https://api.etherscan.io/api?module=proxy&action=eth_getTransactionByBlockNumberAndIndex&tag=" & blockNoHex & "&index=" & transactionIndex & "&apikey=" & API_KEY
        Dim httpClient As New HttpClient()
        Dim response As HttpResponseMessage = Nothing
        Dim content As HttpContent = Nothing
        Dim vBol As String = Nothing

        response = httpClient.GetAsync(apiUrl).Result
        content = response.Content
        Dim blockID As String = insertedID
        Dim json As String = response.Content.ReadAsStringAsync().Result
        Dim responseData As eth_getTransactionByBlockNumberAndIndex = JsonConvert.DeserializeObject(Of eth_getTransactionByBlockNumberAndIndex)(json)
        Dim hash As String = responseData.result.hash.ToString
        Dim [from] As String = responseData.result.from.ToString
        Dim [to] As String = responseData.result.to.ToString
        Dim value As String = ConvertHexToBigInt(responseData.result.value).ToString
        Dim gas As String = ConvertHexToBigInt(responseData.result.gas).ToString
        Dim gasPrice As String = ConvertHexToBigInt(responseData.result.gasPrice).ToString

        vBol = InsertTransactionRecord(blockID, blockNo, transactionIndex, hash, [from], [to], value, gas, gasPrice)

        If vBol Then
            vBol = True
        Else
            vBol = False
        End If

        Return vBol
    End Function

#End Region

#Region "Inserting Data Into DB"
    Function InsertBlockRecord(ByVal blockNo As String,
                          ByVal hash As String,
                          ByVal parentHash As String,
                          ByVal miner As String,
                          ByVal gasLimit As String,
                          ByVal gasUsed As String
                         )

        Dim connectionManager As New MySQLConnectionManager()

        Dim result As String = Nothing

        Try
            connectionManager.Open()
            Dim query As String = ""
            query += "INSERT INTO blocks "
            query += "(blockNumber, hash, parentHash, miner, gasLimit, gasUsed) "
            query += "VALUES "
            query += "(@BLOCK_NUMBER, @HASH, @PARENT_HASH, @MINER, @GAS_LIMIT, @GAS_USED); SELECT LAST_INSERT_ID(); "
            Dim command As New MySqlCommand(query, connectionManager.connection)
            command.Parameters.AddWithValue("@BLOCK_NUMBER", blockNo)
            command.Parameters.AddWithValue("@HASH", hash)
            command.Parameters.AddWithValue("@PARENT_HASH", parentHash)
            command.Parameters.AddWithValue("@MINER", miner)
            command.Parameters.AddWithValue("@GAS_LIMIT", gasLimit)
            command.Parameters.AddWithValue("@GAS_USED", gasUsed)
            'command.ExecuteNonQuery()
            Dim insertedId As Object = command.ExecuteScalar()
            If insertedId IsNot Nothing AndAlso Not DBNull.Value.Equals(insertedId) Then
                Dim primaryKey As Integer = Convert.ToInt32(insertedId)
                result = primaryKey
            End If

            connectionManager.Close()
        Catch ex As Exception
            Console.Write(ex.ToString())
        End Try

        Return result
    End Function

    Function InsertTransactionRecord(ByVal blockID As String,
                                     ByVal blockNo As String,
                                     ByVal transactionIndex As String,
                                     ByVal hash As String,
                                     ByVal [from] As String,
                                     ByVal [to] As String,
                                     ByVal value As String,
                                     ByVal gas As String,
                                     ByVal gasPrice As String
                         )
        Dim connectionManager As New MySQLConnectionManager()

        Dim vBol As String = Nothing

        Try
            connectionManager.Open()
            Dim query As String = ""
            query += "INSERT INTO transactions "
            query += "(blockID, hash, from_r, to_r, value, gas, gasPrice, transactionIndex) "
            query += "VALUES "
            query += "(@BLOCK_ID, @HASH, @FROM, @TO, @VALUE, @GAS, @GAS_PRICE, @TRANSACTION_INDEX); "
            Dim command As New MySqlCommand(query, connectionManager.connection)
            command.Parameters.AddWithValue("@BLOCK_ID", blockID)
            command.Parameters.AddWithValue("@HASH", hash)
            command.Parameters.AddWithValue("@FROM", [from])
            command.Parameters.AddWithValue("@TO", [to])
            command.Parameters.AddWithValue("@VALUE", value)
            command.Parameters.AddWithValue("@GAS", gas)
            command.Parameters.AddWithValue("@GAS_PRICE", gasPrice)
            command.Parameters.AddWithValue("@TRANSACTION_INDEX", ConvertHexToInt(transactionIndex).ToString)
            command.ExecuteNonQuery()
            connectionManager.Close()
            vBol = True
        Catch ex As Exception
            vBol = False
            Console.Write(ex.ToString())
        End Try

        Return vBol
    End Function

#End Region

    '----------------------------------------------------------------------------------------------------------------------

#Region "Misc Functions"
    Public Function ConvertDecToHex(ByVal decimalNumber As Integer)
        Dim hexadecimalNumber As String = decimalNumber.ToString("X")
        Return "0x" & hexadecimalNumber
    End Function

    Public Function ConvertHexToInt(ByVal hexNo As String)
        Dim removeOx As String = hexNo.Substring(2).ToString
        Dim decimalNumber As Integer = Convert.ToInt32(removeOx, 16)
        Return decimalNumber
    End Function

    Public Function ConvertHexToBigInt(ByVal hexNo As String)
        Dim removeOx As String = hexNo.Substring(2).ToString
        'Dim hexValue As String = "FFFFFFFFFFFFFFFF"
        Dim bigIntegerValue As BigInteger = BigInteger.Parse(removeOx, System.Globalization.NumberStyles.AllowHexSpecifier)
        Dim decimalNumber As String = bigIntegerValue.ToString
        'Dim decimalNumber As BigInteger = BigInteger.Parse(removeOx, System.Globalization.NumberStyles.HexNumber)
        'Dim decimalNumber As BigInteger = Convert.ToInt64(removeOx, 16)
        Return decimalNumber
    End Function

    Sub LogDataBlock(ByVal blockNo As String, ByVal processedTimeBlock As String)
        Dim logFilePath As String = "logs\logBlock.txt"
        Dim lines As New List(Of String)(File.ReadAllLines(logFilePath))
        Dim curCount As Integer = lines.Count
        Dim count As String = curCount + 1
        Using writer As New StreamWriter(logFilePath, True, Encoding.UTF8)
            writer.WriteLine($"{count}. Block Number: {blockNo}({ConvertDecToHex(blockNo)}) ->  TimeStamp: {DateTime.Now}, Processing Time: {processedTimeBlock}")
        End Using
    End Sub

    Sub LogDataTransaction(blockNo As String, transactionIndex As String, ByVal processedTime As String)
        Dim logFilePath As String = "logs\logTransaction.txt"
        Dim lines As New List(Of String)(File.ReadAllLines(logFilePath))
        Dim curCount As Integer = lines.Count
        Dim count As String = curCount + 1
        Using writer As New StreamWriter(logFilePath, True, Encoding.UTF8)
            writer.WriteLine($"{count}. Block Number: {blockNo}({ConvertDecToHex(blockNo)}); Transaction Number: {ConvertHexToInt(transactionIndex)}({transactionIndex})  ->  TimeStamp: {DateTime.Now}, Processing Time: {processedTime}")
        End Using
    End Sub

#End Region

End Module
