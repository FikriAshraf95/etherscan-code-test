To run this program:-
1. Go to folder 'etherscan-test'
2. Go to folder 'bin'
3. Go to folder 'debug'
4. Go to folder 'net6.0'
5. Find and run the program 'etherscan-test.exe'

All the information are saved in mysql database at:-
http://159.223.74.140/phpmyadmin/index.php?route=/database/structure&server=1&db=etherscan

Logs path:-
etherscan-test\etherscan-test\bin\Debug\net6.0\logs

Credentials:-
Username: etherscan_all
Password: etherscan
Or
Username: root
Password: 
